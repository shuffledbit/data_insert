<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
} 

else
{
echo "connection established";
}


$department_name=$_POST['department_name'];
 $response=array();

$sql="INSERT INTO department(dept_name) VALUES('$department_name')";

if(mysqli_query($conn, $sql))
{
 $response['error']=false;
$response['message']="Registered successfully";

}
else
{
 $response['error']=true;
$response['message']="invalid request";
}

echo json_encode($response);
?>